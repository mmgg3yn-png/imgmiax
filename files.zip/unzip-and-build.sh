#!/usr/bin/env bash
# اسم الملف: unzip-and-build.sh
# وضع التنفيذ: chmod +x unzip-and-build.sh
# تشغيل (مطوّع): ./unzip-and-build.sh [--yes] [--variant assembleDebug]
#
# السلوك:
#  - ينشئ فرع احتياطي ويحفظ الحالة الحالية (backup).
#  - يحذف كل شيء في الجذر باستثناء .git و IMGmiax-ready.zip.
#  - يفك الأرشيف وينقل محتويات IMGmiax/ إلى الجذر إن وجدت.
#  - يبني المشروع باستخدام Gradle.
#  - يرتكب ويدفع التغييرات إلى الفرع الحالي.
set -euo pipefail

# ---- إعدادات افتراضية (يمكن تعديلها بالوسائط أو المتغيرات البيئية) ----
ZIP="IMGmiax-ready.zip"
KEEP_LIST=( ".git" "$ZIP" )   # ادخل أسماء ملفات/مجلدات ترغب بالحفاظ عليها هنا
BACKUP_BRANCH_PREFIX="backup-before-unpack"
BUILD_TASK="assembleDebug"    # افتراضياً يبني debug. استخدم --variant assembleRelease لتغيير
GIT_PUSH=true                # حاول دفع التغييرات بعد الالتزام

# ---- معالجة الوسائط ----
AUTO_CONFIRM=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y)
      AUTO_CONFIRM=1
      shift
      ;;
    --variant)
      if [[ -n "${2:-}" ]]; then
        BUILD_TASK="$2"
        shift 2
      else
        echo "خطأ: --variant يتطلب قيمة مثل assembleDebug أو assembleRelease"
        exit 1
      fi
      ;;
    --no-push)
      GIT_PUSH=false
      shift
      ;;
    *)
      echo "خيار غير معروف: $1"
      echo "الاستخدام: $0 [--yes] [--variant assembleDebug|assembleRelease] [--no-push]"
      exit 1
      ;;
  esac
done

# ---- تحققات أولية ----
if [[ ! -f "$ZIP" ]]; then
  echo "لم أجد $ZIP في جذر المستودع. ضع الأرشيف ثم شغّل السكربت."
  exit 1
fi

# تأكيد المستخدم ما لم يطلب تجاوز التأكيد
if [[ $AUTO_CONFIRM -ne 1 ]]; then
  echo "تنبيه: هذا السكربت سيحذف كل ملفات الجذر في المستودع (باستثناء: ${KEEP_LIST[*]})."
  read -p "هل أنت متأكد متابَعة؟ اكتب y للموافقة: " ans
  if [[ "${ans,,}" != "y" ]]; then
    echo "ألغيت التشغيل."
    exit 0
  fi
fi

# ---- احصل على الفرع الحالي ----
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "هذا الدليل ليس مستودع Git. تأكد من تشغيل السكربت داخل جذر المستودع."
  exit 1
fi

CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
TIMESTAMP=$(date +%Y%m%d%H%M%S)
BACKUP_BRANCH="${BACKUP_BRANCH_PREFIX}-${TIMESTAMP}"

echo "الفرع الحالي: $CURRENT_BRANCH"
echo "إنشاء فرع احتياطي: $BACKUP_BRANCH"

# ---- إنشاء الفرع الاحتياطي وحفظ كل التغييرات الحالية ----
git checkout -b "$BACKUP_BRANCH"
# إضافة كل الملفات (حتى غير المراقبة) ثم commit؛ إذا لم توجد تغييرات سيفشل commit ونتابع
git add -A || true
if git diff --cached --quiet; then
  echo "لا توجد تغييرات جديدة لالتزام في الفرع الاحتياطي."
else
  git commit -m "Backup before unpacking ${ZIP} at ${TIMESTAMP}" || true
fi

# ادفع الفرع الاحتياطي إن أمكن
echo "محاولة دفع الفرع الاحتياطي إلى remote..."
git push -u origin "$BACKUP_BRANCH" || echo "فشل الدفع - قد لا تكون لديك صلاحية أو لا يوجد remote."

# ارجع للفرع الأصلي (أو أنشئه إن لم يكن موجوداً نفس الاسم بعد checkout)
git checkout "$CURRENT_BRANCH" >/dev/null 2>&1 || git checkout -b "$CURRENT_BRANCH"

# ---- تنظيف: حذف كل شيء ما عدا قائمة KEEP_LIST ----
echo "تنظيف الملفات (حذف كل شيء ما عدا: ${KEEP_LIST[*]})..."
shopt -s dotglob nullglob
for entry in * .[!.]* ..?*; do
  skip=false
  for k in "${KEEP_LIST[@]}"; do
    if [[ "$entry" == "$k" ]]; then
      skip=true
      break
    fi
  done
  if $skip; then
    continue
  fi
  # احذر من حذف نفسه أثناء التنفيذ؛ إن لم يتم الحذف تابع
  rm -rf -- "$entry" || true
done

echo "بعد التنظيف:"
ls -la

# ---- فك ZIP ----
echo "فك $ZIP ..."
unzip -o "$ZIP" -d . >/dev/null

# ---- إن وُجد مجلد IMGmiax/ انقل محتوياته إلى الجذر ----
if [[ -d "IMGmiax" ]]; then
  echo "نقل محتويات IMGmiax/ إلى الجذر..."
  shopt -s dotglob
  mv IMGmiax/* . || true
  rm -rf IMGmiax || true
fi

echo "محتويات الجذر بعد الفك:"
ls -la

# ---- تأكد gradlew قابل للتنفيذ ----
if [[ -f "./gradlew" ]]; then
  chmod +x ./gradlew || true
fi

# ---- بناء المشروع باستخدام Gradle ----
echo "بدء البناء: ./gradlew $BUILD_TASK"
# حاول استخدام متوفر JDK على النظام (GitHub runner عادةً لديه JDK)، هنا لا نحاول ضبط JAVA_HOME محليًا
if [[ -f "./gradlew" ]]; then
  # استخدم --no-daemon لتقليل مشاكل البيئة
  ./gradlew "$BUILD_TASK" --no-daemon || {
    echo "فشل البناء باستخدام ./gradlew. حاول تشغيل ./gradlew $BUILD_TASK يدوياً للتحقق من الأخطاء."
    # لا نخرج فورًا، نتابع الالتزام والرفع لأن الملفات قد تم استبدالها
  }
else
  echo "لم أجد ملف gradlew. تأكد من توفر Gradle أو استخدم Gradle wrapper."
fi

# ---- الالتزام ورفع التغييرات ----
echo "الالتزام بالملفات الجديدة..."
git add -A || true
if git diff --cached --quiet; then
  echo "لا تغييرات للالتزام."
else
  git commit -m "Replace repo contents with ${ZIP} and build (${BUILD_TASK})" || true
  if $GIT_PUSH; then
    echo "دفع التغييرات إلى الفرع $CURRENT_BRANCH..."
    git push origin "$CURRENT_BRANCH" || echo "فشل الدفع - تحقق من صلاحياتك أو إعدادات الحماية على الفرع."
  else
    echo "تخطّي الدفع حسب خيار --no-push."
  fi
fi

# ---- نتائج البناء وإخراج ----
echo "تم التنفيذ. تحقق من موقع الـ APK (إن وجد):"
echo " - app/build/outputs/apk/ (تحقق من debug/ أو release/ حسب البناء)"
echo "انتهى السكربت."
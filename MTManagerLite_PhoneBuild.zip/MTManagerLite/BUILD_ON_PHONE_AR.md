# بناء APK من الهاتف عبر GitHub Actions

1. فك ضغط MTManagerLite_AndroidStudio.zip.
2. أنشئ مستودعًا جديدًا على GitHub من المتصفح.
3. ارفع محتويات المجلد إلى جذر المستودع (يجب أن يظهر app/ وbuild.gradle.kts وsettings.gradle.kts و.github/workflows/android.yml مباشرة في الجذر).
4. افتح تبويب Actions في المستودع، واختر Build MT Manager Lite APK، ثم Run workflow.
5. انتظر انتهاء البناء بنجاح.
6. افتح تشغيل workflow الناجح وانزل إلى Artifacts، ثم نزّل MTManagerLite-debug-apk.
7. فك ضغط ملف Artifact؛ ستجد app-debug.apk. افتحه للتثبيت واسمح للمتصفح/مدير الملفات بالتثبيت من هذا المصدر عند الطلب.

ملاحظات:
- يتطلب اتصال إنترنت وحساب GitHub.
- لا تضع كلمات مرور أو مفاتيح خاصة في المستودع.
- APK الناتج نسخة debug للتجربة.
